<?php
/* CONNECTION TO THE DATABASE */
include('connect.php');

/* SQL QUERY STATMENT TO DELETE RECORD(s)*/
$sql="insert into books values ('$_REQUEST[ID_BOOK]','$_REQUEST[TITLE_BOOK]','$_REQUEST[DOE_BOOK]','$_REQUEST[COPIES_BOOK]')";

/* QUERY EXECUTION */
mysqli_query($con,$sql) or die("Error query!");

/* SHOWING QUERY RESULT ON SCREEN */
echo"Record Inserted =".mysqli_affected_rows($con);
 
/* CLOSE CONNECTION TO DATABASE */
mysqli_close($con);
?>
