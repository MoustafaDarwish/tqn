<?php
/* CONNECTION TO THE DATABASE */
include('connect.php');

/* SQL QUERY STATMENT TO DELETE RECORD(s)*/
$sql="delete from books where id_book='$_REQUEST[ID_BOOK]'";

/* QUERY EXECUTION */
mysqli_query($con, $sql) or die ("error query");

/* SHOWING QUERY RESULT ON SCREEN */
echo mysqli_affected_rows($con)." Record Deleted!";

/* CLOSE CONNECTION TO DATABASE */
mysqli_close($con);

?>
