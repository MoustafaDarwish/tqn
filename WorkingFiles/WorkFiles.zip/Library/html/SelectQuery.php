<?php
/* CONNECTION TO THE DATABASE */
include('connect.php');
/* إدراج جملة الربط بملف التنسيق قصد تطبيق تنسيق للجدول*/
echo "<link href=\"formatting.css\" rel=\"stylesheet\" type=\"text/css\"/>";

/* SQL QUERY STATMENT TO SELECT RECORD(s)*/
$sql = "select * from books where copies_book < '$_REQUEST[COPIES_BOOK]'";

/* EXECUTE THE QUERY ANS STORE RESULT INTO RESULT VARIABLE */
$result=mysqli_query($con,$sql);

/* PRINTING ON SCREEN THE HEAD OF THE TABLE (1ST ROW) WILL CONTAINING THE QUERY RESULT */
echo "<table><tr><th>BOOK ID</th><th>TITLE BOOK</th><th>DATE OF EDITION</th><th>NUMBER OF COPIES</th></tr>";

/**/
while($row=mysqli_fetch_array($result))

{
	echo "<tr>";
	
		echo "<td>".$row['id_book']."</td>";
		echo "<td>".$row['title_book']."</td>";
		echo "<td>".$row['doe_book']."</td>";
		echo "<td>".$row['copies_book']."</td>";
			
	echo"</tr>";
} /* end loop */
echo "</table>";

/* CLOSE CONNECTION TO DATABASE */
mysqli_close($con);


?>

