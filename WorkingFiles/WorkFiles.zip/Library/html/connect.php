<?php
$con = mysqli_connect("localhost", "root", "", "library");

if(!$con){echo "Connection Failed!!"."<br/>";}
		else {echo"Connection succeeded"."<br/><br/>";}	
?>
