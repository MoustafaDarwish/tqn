<?php

/* CONNECTION TO THE DATABASE */
include('connect.php');

/* SQL QUERY STATMENT TO UPDATE RECORD(s)*/
$sql="update books set title_book='$_REQUEST[TITLE_BOOK]',doe_book='$_REQUEST[DOE_BOOK]',copies_book='$_REQUEST[COPIES_BOOK]' where id_book='$_REQUEST[ID_BOOK]'";

/* QUERY EXECUTION */
mysqli_query($con,$sql) or die ("error query");

/* SHOWING QUERY RESULT ON SCREEN */
echo mysqli_affected_rows($con)." Record updated";

/* CLOSE CONNECTION TO DATABASE */
mysqli_close($con);

?>
