<?php
include('table.php');
include('connect.php');
$sql="select * from books where copies_book".  $_REQUEST['COPIES_BOOK'];
$result=mysqli_query($con,$sql);

echo "<table><tr><th>BOOK ID</th><th>TITLE BOOK</th><th>DATE OF EDITION</th><th>NUMBER OF COPIES</th></tr>";

while($row=mysqli_fetch_array($result))

{
	echo "<tr>";
	
	echo "<td>".$row['id_book']."</td>";
	echo "<td>".$row['title_book']."</td>";
	echo "<td>".$row['doe_book']."</td>";
	
	if ($row['copies_book'] < 2 )
	{
	echo "<td style=\"background-color:red ;color:white;\">".$row['copies_book']."</td>";
	}
	else
	{echo "<td>".$row['copies_book']."</td>"; }
	
	
	
		
	echo"</tr>";
}
echo "</table>";

mysqli_close($con);

if (1==="1"){  echo   "true";}
else
{

echo "false ";}
?>

